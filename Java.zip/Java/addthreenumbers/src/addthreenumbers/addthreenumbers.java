//supriya Biswas
//program to add three numbers
//05/09/2018
package addthreenumbers;
import java.util.Scanner;//for output
public class addthreenumbers {

	public static void main(String[] args) {
		// declare variables
		int num1=10;
		int num2=20;
		int num3=30;
		int total=0;
		String FirstName = "";
		String SecondName = "";
		int num4;
		int num5;
		String FirstName1 = "";
		String SecondName1 = "";
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the first number:");
		num1 = sc.nextInt();
		
		System.out.print("Enter the second number:");
		num2= sc.nextInt();
		
		System.out.print("Enter the third number:");
		num3 = sc.nextInt();
		
		System.out.print("Enter the first name:");
		FirstName = sc.next();
		
		System.out.print("Enter the Second name:");
		SecondName = sc.next();
		
		System.out.print("Enter the fourth number:");
		num4 = sc.nextInt();
		
		System.out.print("Enter the fifth number:");
		num5 = sc.nextInt();
		
		total = num1 + num2 + num3;//adding the numbers
		
		
		System.out.print("Enter the First name:");
		FirstName1 = sc.next();
		
		System.out.print("Enter the Second name:");
		SecondName1 = sc.next();
		
	
		
		
		System.out.print(" The total of the three numbers is: " + total);;//output to screen
		
		System.out.print(" Your name is " +FirstName +" " +SecondName );
sc.close();
	}                                                    


}
