//Supriya Biswas
//Calling Methods in the SAME CLASS.JAVA
public class CallingMethod {

	public static void main(String[] args) {
		// calling method with the same class
		printOne();//calling method
		printTwo();//calling method

	}
//this is method printOne
	public static void printOne(){
		System.out.println("Hello World");
		//printing Hello ~World to screen
	}
	// this is method printTwo
	public static void printTwo(){
		printOne();//calling method printOne twice
		printOne();
	}
}
