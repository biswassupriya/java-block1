//supriya biswas
//10/10/2018
//menu for anniesland fitness club
package excercise7;

public class classcalculatefees {
	// class variables
	private String fName;
	
	
	
	// constructor
	public classcalculatefees(){
		fName = "";
		
	}
	
	// setter for first name
	public void setfName(String name){
		fName = name;
	}
	
	// getter for first name
	public String getfName(){
		return fName;
	}


}
