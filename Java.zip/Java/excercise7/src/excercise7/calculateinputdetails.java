//supriya biswas
//10/10/2018
//menu for anniesland fitness club

package excercise7;

import java.util.Scanner;

public class calculateinputdetails {

	public static void main(String[] args) {
		// declare variables
		
		Scanner sc = new Scanner(System.in);
		
		classcalculatefees check = new classcalculatefees();
	}

}
