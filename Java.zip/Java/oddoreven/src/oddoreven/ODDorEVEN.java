//supriya biswas
//10/10/2018
//find odd or even number using modulus%
package oddoreven;

import java.util.Scanner;

public class ODDorEVEN {
	
	public static void main(String[] args) {
		// declare variables
		
	  int x;
	  Scanner sc = new Scanner(System.in);
	  
      System.out.println("Enter an integer to check if it is odd or even:");
      
      x=sc.nextInt();//input an integer value
	  if(x % 2==0)
	  {
		  System.out.println("you entered an even number.");
	  }
	  else
	{
		System.out.println("You entered am odd number.");
	}
  

}
}
