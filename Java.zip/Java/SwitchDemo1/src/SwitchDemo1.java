//Supriya Biswas
//03/10/2018
//Create a ~Switch Demo Program

import java.util.Scanner;//this is utility built into the java language, called Scaner, allows keyboard input

public class SwitchDemo1 {

	public static void main(String[] args) {
		// declare variables
		
		Scanner sc = new Scanner(System.in);//create object sc for input
		
		int month = 0;
		String monthString = "";
		
		System.out.println("Enter a month number between 1 and 12");
		month = sc.nextInt();//input the month
	
		//switch and case selection code
		switch(month){
		

		case 1: monthString = "January";//if January
                 break;
		case 2:monthString = "February";//if february
		        break;
		case 3: monthString = "March";//if march
		        break;
		case 4:monthString = "April";//if April
		       break;
		case 5:monthString = "May";//if May
		       break;
		case 6:monthString = "June";//if June
		       break;
		case 7:monthString = "July";//if July
		       break;
		case 8:monthString = "August";//if August
		       break;
		case 9:monthString = "September";//if September
		       break;
		case 10:monthString = "October";//if October
		        break;
		case 11:monthString = "November";//if November
		        break;
		case 12:monthString = "December";//if December
		        break;
	}
	
	System.out.println(" The month is " + monthString);
                               

	}
}


