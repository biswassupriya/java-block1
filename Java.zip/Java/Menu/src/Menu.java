//Supriya Biswas
//Program Menu
//24/10/2018
import java.util.Scanner; // import the scanner

public class Menu {

	public static void main(String[] args) {
		// initialise variables
		 int x = 0;
		 int y = 0;
		 int option = 0;
		 Scanner sc = new Scanner(System.in);
		 
		 // set up menu while loop
		 while(option != 6)
		 {
			 // show menu
			 System.out.println("Calculator Menu");
			 System.out.println("1. Enter the numbers");
			 System.out.println("2. Add");
			 System.out.println("3. Subtract");
			 System.out.println("4. Multiply");
			 System.out.println("5. Divide");
			 System.out.println("6. Exit");
			 System.out.println("Enter your choice: ");
			 
			 option = sc.nextInt(); // input the selection
			 
			 //select the correct option
			 switch (option)
			 {
			 case 1 : //enter the two numbers and store in x and y
				 System.out.println("Enter the first number: ");
				 x = sc.nextInt();
				 System.out.println("Enter the second number: ");
				 y = sc.nextInt();
				 break;
				 
			 case 2 : //add numbers
				 System.out.println("you selected addition = " + (x+y));
				 break;
			
			 case 3 : // subtract the numbers
				 System.out.println("you selected subtraction = " + (x-y));
				 break;
				 
			 case 4 : // multiply the numbers
				 System.out.println("you selected multiplication = " + (x*y));
				 break;
				 
			 case 5 : // divide the numbers
				 System.out.println("you selected division = " + (x/y));
				 break;
				 
			 case 6 : // exit
				 System.out.println("Goodbye");
				 sc.close(); // close the scanner
				 break;
				 
			default: System.out.println("Invalid Entry!");	 
			 }//end switch
			 
		 }// end while

	}// end main 

}// end class
