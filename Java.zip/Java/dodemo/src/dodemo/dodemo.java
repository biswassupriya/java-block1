//supriya biswas
//03/10/2018
//create program of dodemo

package dodemo;

public class dodemo {

	public static void main(String[] args) {
		// variables
		
		int count = 1;
		
		//create a do while loop to output the counter
		
		do{
			System.out.println(" The loop counter : " +count);
		}
		while(count<11);
		}

	}


