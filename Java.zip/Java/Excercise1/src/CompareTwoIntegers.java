//Supriya Biswas
//compare two integer values
import java.util.Scanner;//import the keyboard input utility
public class CompareTwoIntegers {

	public static void main(String[] args) {
		// condition
		int num1 = 0;
		int num2 = 0;
		
		Scanner sc = new Scanner(System.in);//create object sc of type scanner
		
		System.out.println("Enter the first value : ");
		num1 = sc.nextInt();//get input
		
		System.out.println("Enter the Second value : ");//create object sc of type scanner
		num2 = sc.nextInt();//get input
		
		if(num1 > num2)
		{
		 System.out.println("value1 is greatest");
		}
		
		if (num1 < num2)
		{
		System.out.println("value 1 is less than value2");
		}
		
        if(num1 == num2)
         {
        	System.out.println("these values are equal"); 
         }
         else
         {
        	 System.out.println("values are not equal");
         }
	}

}
