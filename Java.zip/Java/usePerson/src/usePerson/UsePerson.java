//Supriya Biswas
//03/10/2010
// main class 

package usePerson;
import java.util.Scanner;

public class UsePerson {

	public static void main(String[] args) {
		Person p1 = new Person("Arial",15);//create object p1 of class person
		
		Person p2 = new Person("Joseph",20);//create object p2 of person
		
		//Person p3 = new Person();
		
	
		
	//Scanner sc = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the persons name:");
		p1.setName(sc.nextLine());
		
		System.out.print("Enter  the persons age: ");
		p1.setAge(sc.nextInt());
		
	
	if(p1.getAge() == p2.getAge())

	{
		System.out.println(p1.getName()+ " is the same as " + p2.getName());
	}
	 else
	{
	System.out.println(p1.getName() + " is not the same age as " + p2.getName());	
	}
		
	}
}
		
	  
			
	