//Supriya Biswas
//3/10/2010
//creating two Classes
package usePerson;

public class Person {//this is the data class
	
private String name;//declaring variables
private int age;

//constructor - initialises the variables
public Person(String name,int age)
{
	this.name= name;//using this
	this.age=age;
}

//setter method for name
public void setName(String Fname)
{
	name=Fname;
}

//setter method for age
public void setAge(int newAge)
{
	age = newAge;
}

//getter method for name
public String getName()
{
	return name;
}

//getter method for age
public int getAge()
{
	return age;
}
}

