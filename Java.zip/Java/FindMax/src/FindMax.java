//Supriya Biswas
//find the maximum of two numbers
//12/09/2018
public class FindMax {

	public static void main(String[] args) {
		//variables
		int i = 5;
		int j = 2;
		int k = max(i,j);//call method max to find the biggest value
		System.out.println("The maximum between" + i + " and " + j + " is " +k);
	
	}
      //Method to return the max between the two numbers
	public static int max(int num1,int num2){//these are input parameters in result
		int result;
		if(num1 > num2)//greater than selection)
				{
			 result=num1;
				}
		else
		{
			result=num2;
		}
		return result;
		//returns the output parameter result to the main
		
	}
}
