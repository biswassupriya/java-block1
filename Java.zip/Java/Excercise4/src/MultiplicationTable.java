//Supriya Biswas
//26/09/2018
//create a multiplication table
import java.util.Scanner;
public class MultiplicationTable {

	public static void main(String[] args) {
		//declare variables
		
		int value = 0;
		int table = 0;
		
		Scanner sc = new Scanner(System.in);
		//inputs
		
		System.out.println("Enter the value:");
		value = sc.nextInt();
		
		
		//do the times tables
		for(int i=1;i<11;i++)
		{
			table = value*i;	
			System.out.println("Times table:"+i+ "*" +value +"=" +table);//outputs
		}
	}
	

	}


