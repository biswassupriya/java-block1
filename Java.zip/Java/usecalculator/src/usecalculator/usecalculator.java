//supriya biswas
//10/10/2018
//this is main class of calculator
package usecalculator;
 
import java.util.Scanner;

public class usecalculator {

	public static void main(String[] args) {
		// declare variables
		
		float amount = 0;
		float tip = 0;
		float payment = 0;
		
		Scanner sc = new Scanner(System.in);
		
		classcalculator check = new classcalculator();
		
		System.out.println("Enter the amount of bill:");
		
		amount = sc.nextFloat();
		
		System.out.println("Enter the percent amount you would like to tip:");
		
		tip = sc.nextFloat();
		
		payment = check.calculateTip(amount,tip);
		
		System.out.printf("The total amount will be:�%.2f", payment);

	}

}
