//supriya biswas
//10/10/2018
//compute the tip value in to 2 decimal places
package usecalculator;

public class classcalculator { // this class contains the method which calculates the tip for a bill



		// variables
		private  float totalWithtip;
		private float tipPercent;
		
		//constructor to initialise the variables
		public  void calculator(){
			  int totalWithTip = 0;
			   tipPercent = 0;
		}
		
       public float calculateTip(float amount, float tip){
    	   
    	    tipPercent = tip/100;
    	     float totalWithTip = amount + (amount*tipPercent);
    	    
    	    return totalWithTip;
       }
	}


