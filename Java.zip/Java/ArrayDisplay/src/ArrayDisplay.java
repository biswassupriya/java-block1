//Supriya Biswas
//10/10/2018
//program called ArrayDisplay
public class ArrayDisplay {

	public static void main(String[] args) {
		// variables
		
		int[] numbers = new int[10];//create an array 10 integer value
		int x = 3;
		
		for(int i =0;i<10;i++)
		{
			numbers[i] = x;//store x into the array at element i
			x = x*2; // change the value of x
		}
		
		for(int i = 0;i < 10;i++)
		{
			System.out.println(numbers[i]);//output the array values
		}
		
	}

}
