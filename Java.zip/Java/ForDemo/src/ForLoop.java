//Supriya Biswas
//26/09/2018
//program ForDemo
public class ForLoop {

	public static void main(String[] args) {
		// create a for loop to output the loop counter i
		for(int i=1;i<11;i++)
		{
			System.out.println("The loop counter is :" +i);
		}
			
			
		
		

	}

}
