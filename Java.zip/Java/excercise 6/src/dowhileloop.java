// supriya biswas
//10/10/2018
//program to display all the even numbers 

import java.util.Scanner;

public class dowhileloop {

	public static void main(String[] args) {
		// declare variables
		
		int count = 0;
		
		Scanner sc = new Scanner(System.in);
		
			do
			{
				if (count%2 == 0)
				{
					System.out.println("Display all the even numbers of loop counter:"+count);
				}
				count++;
			} while(count<20);
			
		}

	}


