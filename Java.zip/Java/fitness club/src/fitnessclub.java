// menu for Anniesland Fitness club
//supriya Biswas
//24/10/2018
//excercise 7

public class fitnessclub {
// variables
	private String firstName;
	private String lastName;
	private String Town;
	private int fees;
	
// constructor
	public fitnessclub(){
		firstName = "";
		lastName = "";
		Town = "";
		fees = 0; // set fee to zero
	
	}
	
// setter for firstName
	public void setfirstName (String name)
	{
		firstName = name;
	}
	
// setter for lastName
	public void setlastName(String name)
	{
			lastName = name;
			
	}
	
// setter for Town
	public void setTown(String name)
	{
	  	Town = name;
	}
		
// setter for fees	
	
	public void setfees(int fees)
	{
		int result = Town.compareTo("Glasgow");  // test for town = Glasgow
		
		if (result == 0)
			fees = 100;  // Glasgow
		else
			fees = 130;  // Not Glasgow
	
	}
	
	
	
	
// getter for firstName	
	public String getfirstName()
	{
		return firstName;
	}
	
// getter for lastName	
	public String getlastName()
	{
		return lastName;
	}
	
//getter for Town	
	public String getTown()
	{
		return Town;
	}
	
//getter for fees	
	public int getfees()
	{
		return fees;
	}
	
	
}
