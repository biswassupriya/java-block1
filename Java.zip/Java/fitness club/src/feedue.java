//excercise 7
//supriya biswas
//menu for anniesland fitness club
//24/10/2018
public class feedue {

	public static void main(String[] args) {
		// declare variables
		int x = 100;
		int y = 130;
		

	}

}
