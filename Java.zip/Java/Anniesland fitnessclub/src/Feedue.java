//Supriya Biswas
//Fee due class
//31/10/2018
public class Feedue {
	//instance variables
	private String firstName;
	private String lastname;
	private String town;
	private int fees;
	
	// constructor - set fee to a default zero
	public Feedue()
	{ //initialise class variables
		firstName = "";
		lastname = "";
		town = "";
		fees = 0; // set fee to zero
	}
	
	// setter for first name
	public void SetfirstName(String input)
	{
		firstName = input;
	}
		
	// setter for lastname
	public void Setlastname(String input)
	{
		lastname = input;
	}
	
	//setter for town
	public void Settown(String input)
	{
		town = input;
	}
	
	//setter for fee for Glasgow
	public void setFee(String town)
	{ //compare the input value town to the word Glasgow
	   int result = town.compareTo("Glasgow");
	   
	   // set the fee for Glasgow or not Glasgow
	   if (result == 0)
	   {
		   fees = 100; // set fee to 100
	   }
	   else
	   {
		   fees = 130; //set fee to 130
	   }
		
	}
	// getter for the first name
	public String getfirstName()
	{
		return firstName;
	}
	
	//getter for the last name
	public String getlastname()
	{
		return lastname;
	}
	
	//getter for the town
	public String gettown()
	{
		return town;
	}
	
	// getter for fee
	public int getfee()
	{
		return fees;
	}
	
}

	
		

	


