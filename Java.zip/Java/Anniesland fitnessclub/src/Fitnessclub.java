//supriya Biswas
//Menu for Anniesland Fitness club
//31/10/2010

import java.util.Scanner;
public class Fitnessclub {

	public static void main(String[] args) {
		// class variables
		int option = 0;
		
		Scanner sc = new Scanner(System.in);
		
		Feedue custfee = new Feedue(); //an object called custfee of class Feedue
		
		//menu quit when 4 selected
		while(option !=4)
		{
			
			System.out.println("Menu");
			System.out.println("1-input details");
			System.out.println("2-calculate fees");
			System.out.println("3-output details");
			System.out.println("4-Exit");
			
			System.out.println("Enter option: ");
			option = sc.nextInt(); //input option
			
			// validate a correct option entered
			while (option<1||option>4)
			{
				if(option<1||option>4)
				{
					System.out.println("invalid-enter 1-4");
				}
				System.out.println("Enter option:");
				option = sc.nextInt();
			}
			//switch / case statments to carry out operations
			switch(option)
			{
			case 1: System.out.println("Enter firstName:");
			        custfee.SetfirstName(sc.next()); // use setters to receive input
			        
			        System.out.println("Enter lastname:");
			        custfee.Setlastname(sc.next());
			        
			        System.out.println("Enter town:");
			        custfee.Settown(sc.next());
			        break;
			        
			case 2: custfee.setFee(custfee.gettown()); //use the getter to send the town to set fee
			        break;
			case 3: System.out.println("Details are:");
			        System.out.println("firstName lastname town fees");
			        //use the getters to retrieve the data from custfee
			        System.out.println(custfee.getfirstName()+" "+custfee.getlastname()+" "+custfee.gettown()+" "+custfee.getfee());
			        break;
			case 4: sc.close(); // close scanner
			        break;
			}//close switch
			
		}//close switch

	}//close switch

}
