import java.util.Scanner;

//Supriya Biswas
//Compare two integer values
//12/09/2018

import java.util.Scanner;//import the keyboard input utility
public class DeclareValues {

	public static void main(String[] args) {
		// Comparison and conditions
		int value1 = 0;
		int value2 = 0;
		
		Scanner sc = new Scanner(System.in);//create object sc of type scanner
		
		System.out.print("Enter the first value:");
		value1 = sc.nextInt();
		
		System.out.print("Enter the second value:");
		value2 = sc.nextInt();
		
		if(value1>value2)
		{
			System.out.println("value1 is greatest");
		}
		if(value1<value2)
		{
			System.out.println("value1 is less than value2");
		}
		if(value1==value2)
		{
			System.out.println("these values are equal");
		}
		else
		{
			System.out.println("values are not equal");
		}

	}

}
