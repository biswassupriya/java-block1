package excercise1b;
//Supriya Biswas
//Comparing integers
//12/09/2018
import java.util.Scanner;//get the keyboard input utility
public class Comparintwointegers {

	public static void main(String[] args) {
		// if else conditions
		int num1 = 0;
		int num2 = 0;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter the first value");
		num1 = sc.nextInt();
		
		System.out.println("enter the second value");
		num2 = sc.nextInt();
		
		if(num1 > num2)
		{
		System.out.println("number1 is greatest");	
		}
		if(num1 < num2)
		{
			System.out.println("number2 is greatest");
		}
		if(num1 == num2)
		{
			System.out.println("numbers are equal");
		}
		else
		{
			System.out.println("numbers are not equal");
		}

	}

}
