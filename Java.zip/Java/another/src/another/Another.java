//Supriya Biswas
//10/10/2018
//program to imports a static utility called Math

package another;

import java.lang.Math;

public class Another {

	public static void main(String[] args) {
		// declare variables
		
		int result;
		
		result = Math.min(10, 20);
		//calling static method min that comes from the utility Math
		
		System.out.println(result);
		
		// calling ststic method max
		
		System.out.println(Math.max(100, 200));
	}

}
