//supriya
//hello world example
//05/09/2018
public class helloworld {

	public static void main(String[] args) {
		// my program code
		System.out.println("hello world" + " my age is " + 21);//print out to screen

	}

}
