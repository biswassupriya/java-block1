//supriya biswas
//10/10/2018
//while loop program 
import java.util.Scanner;
public class WHILELOOP {

	public static void main(String[] args) {
		// declare variable
		
		int x = 10;
		Scanner sc = new Scanner(System.in);
		// create a output value of x to the loop counter
		while(x < 20)
		{
			System.out.println("The loop counter:" +x);
			x++;//add 10 to count
		}
		

	}

}
