//Supriya Biswas
//03/10/2018
//create a program whiledemo

package whiledemo;

public class whiledemo {

	public static void main(String[] args) {
		// variables
		
		int count = 1;
		
		//create a while loop to output the loop counter
		
		while(count<21)
		{
			System.out.println("The loop counter : " +count);
			count++;//add 1 to count
		}

	}

}
