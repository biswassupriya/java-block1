//Supriya Biswas
//declare variables
//19/09/2018
package declarevariables;
import java.util.Scanner;//output
public class DeclareVariables {

	public static void main(String[] args) {
		// declare variables
		int num = 0;
		double d = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter gallons");
		num = sc.nextInt();
		 

		d = num * 3.785;
		
		
		System.out.println("the litre is :"+ d);//output screen
			
		 
		
		
		
	
		
		

	}

}
