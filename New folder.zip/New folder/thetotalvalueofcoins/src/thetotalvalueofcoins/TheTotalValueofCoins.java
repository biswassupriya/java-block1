//Supriya Biswas
//the total value of coins
//19/09/2018
package thetotalvalueofcoins;
import java.util.Scanner;//output
public class TheTotalValueofCoins {

	public static void main(String[] args) {
		// variables
		double quarters  = 0;
		double dimes = 0;
		double nickels = 0;
		double pennies = 0;
		double dollar = 0;
		double total = 0;
		
		 
		Scanner sc = new Scanner(System.in);//ouput 
		
		System.out.println("Enter quarters:");
		quarters = sc.nextInt();
		
		     dollar = 0.25*quarters;
		     total = total + dollar;
		     
	         System.out.println("dollars:"+dollar);
	        
	      System.out.println("Enter dimes:");
	      dimes = sc.nextInt();
	         
	          dollar = 0.10*dimes;
	          total = total + dollar;
	          
	          System.out.println("dollars:" +dollar);
	          
	     System.out.println("Enter nickles:"); 
	       nickels = sc.nextInt();
	       
	       
	           dollar = 0.05*nickels;
	           total = total + dollar;
	           System.out.println("dollars:"+dollar);
	           
	     System.out.println("Enter pennies:"); 
	     pennies = sc.nextInt();
	     
	        dollar = 0.01*pennies;
	        total = total + dollar;
	        
	       
	        System.out.format(" CALCULATE dollar: %.2f ",total);
	        
	       
	        
	     
	         
	          
	        
	        
				
		
		
		
	
		

	}

}
