//Supriya Biswas
//convert the Greeting to upper case letters
//19/09/2018
import java.util.Scanner;
public class Greeting {

	public static void main(String[] args) {
		// variables
		Scanner sc = new Scanner(System.in);//create object sc to allow
		//access to the input code
		String usersName;//The user's name, as entered by the user.
		String upperCaseName;//The user's name, converted to upper case
		
		System.out.print("Please enter your name:");
		usersName=sc.nextLine();
		
		upperCaseName = usersName.toUpperCase();
		
		System.out.println("Hello,"+ upperCaseName +", nice to meet you!" );
		System.out.println("The Length of the users name is :"+"+upperCaseName.Length()");//gets the length of the string
		
		
		

	}

}
